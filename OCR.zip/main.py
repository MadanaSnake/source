import os
import pytesseract
from PIL import Image
import shutil

def find_tesseract():
    tesseract_path = shutil.which("tesseract")
    if tesseract_path:
        return tesseract_path
    user_folder = os.path.expanduser("~")
    common_paths = [
        os.path.join(user_folder, "AppData", "Local", "Programs", "Tesseract-OCR", "tesseract.exe"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    ]
    for path in common_paths:
        if os.path.exists(path):
            return path
    return None

tesseract_exe = find_tesseract()
if tesseract_exe:
    pytesseract.pytesseract.tesseract_cmd = tesseract_exe
else:
    print("I have no dependencies to run on, please download the dependencies to use me!  https://tinyurl.com/hjA2567Ag\nSorry for the inconvenience!")
    exit(1)


def detect_text_from_folder(base_folder):
    scan_folder = os.path.join(base_folder, "Scan Image")
    output_folder = os.path.join(base_folder, "Result")

    os.makedirs(scan_folder, exist_ok=True)
    os.makedirs(output_folder, exist_ok=True)

    files = os.listdir(scan_folder)
    image_files = [file for file in files if file.lower().endswith((".png", ".jpg", ".jpeg"))]

    if not image_files:
        print(f"No image on '{scan_folder}'! Fill with your texted image to extract the text (.png, .jpg, .jpeg).\nNo folder? I've created you two of them!")
        return

    for file_name in image_files:
        image_path = os.path.join(scan_folder, file_name)
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image).strip()

        data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
        confidences = [conf for conf in data["conf"] if conf != -1]  
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        print(f"\nImage: {file_name}")
        print(f"Accuracy: {avg_confidence:.2f}%")

        # Simpan hasil di file teks dengan nama yang sama
        text_file_path = os.path.join(output_folder, os.path.splitext(file_name)[0] + ".txt")
        with open(text_file_path, "w", encoding="utf-8") as f:
            f.write(text)

    print(f"\nYour extracted image is in '{output_folder}'.")

# Contoh penggunaan
detect_text_from_folder(os.getcwd())  # Gunakan folder tempat skrip berjalan
